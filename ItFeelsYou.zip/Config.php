<?php 
 define('DB_USERNAME','root');
 define('DB_PASSWORD','Pass@123');
 define('DB_NAME','Feelsyou');
 define('DB_HOST','localhost');

?>
