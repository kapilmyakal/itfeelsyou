<?php
 $usertimestamp['timestamp'] = round(microtime(true) * 1000);

    echo json_encode($usertimestamp);
?>
