<?php
$content = file_get_contents('http://18.191.179.1/Upload/uploads/2.png');
file_put_contents('kapil.png', $content);
?>
